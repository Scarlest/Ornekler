
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE spKullaniciYetkisiniGuncelle
@pMail varchar(50),@pYetki tinyint
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE tKullanicilar
	SET Yetki=@pYetki
	WHERE ePosta=@pMail;
END
GO
